const translations = {
    uk: {
        common: {
            nav_label_main: "НАВІГАЦІЯ",
            nav_dashboard: "📊 Дашборд",
            nav_courses: "📖 Мої курси",
            nav_tasks: "📝 Завдання",
            nav_schedule: "📅 Розклад",
            nav_grades: "⭐ Оцінки",
            nav_shop: "💎 Крамниця",
            nav_label_community: "СПІЛЬНОТА",
            nav_announcements: "📢 Оголошення",
            nav_notifications: "🔔 Сповіщення",
            nav_profile: "👤 Профіль",
            nav_discussions: "💬 Обговорення",
            nav_grading: "📝 Перевірка",
            logout_btn: "🚪 Вийти з акаунту",
            theme_dark: "Темна тема",
            theme_light: "Світла тема",
            roles_for_redirect: {
                student: "студента",
                teacher: "викладача",
                moderator: "модератора"
            },
            roles: {
                student: "Студент",
                teacher: "Викладач",
                moderator: "Модератор"
            },
            go_back: "Повернутися",
            redirecting: " Повертаємо вас до вашого кабінету...",
            nav_grading: "📝 Перевірка",
            nav_constructor: "🔧 Конструктор",
            cancel: "Скасувати"
        },
        login: {
            welcome_badge: "ЛАСКАВО ПРОСИМО",
            hero_title: "З поверненням до навчання",
            hero_subtitle: "Ваші курси, завдання та оцінки чекають на вас. Увійдіть, щоб продовжити.",
            stat_students: "Студентів",
            stat_courses: "Курсів",
            stat_tasks: "Завдань",
            title: "Вхід",
            subtitle: "Введіть ваші облікові дані",
            email_label: "ЕЛЕКТРОННА ПОШТА",
            password_label: "ПАРОЛЬ",
            forgot_link: "Забули пароль?",
            remember_me: "Запам'ятати мене",
            login_btn: "Увійти →",
            no_account: "Немає акаунту?",
            register_link: "Зверніться до адміністратора"
        },
        password_reset: {
            forgot_title: "Відновлення пароля",
            forgot_subtitle: "Введіть email, і ми надішлемо посилання для відновлення пароля.",
            send_link: "Надіслати посилання",
            link_sent: "Якщо акаунт з таким email існує, ми надіслали лист для відновлення пароля.",
            back_to_login: "Повернутися до входу",
            reset_title: "Новий пароль",
            reset_subtitle: "Введіть новий пароль і підтвердіть його.",
            new_password: "Новий пароль",
            confirm_password: "Підтвердіть пароль",
            update_password: "Оновити пароль",
            password_updated: "Пароль успішно оновлено."
        },
        dashboard: {
            welcome: "Вітаю",
            status_loading: "Отримуємо актуальну інформацію...",
            user_loading: "Завантаження...",
            title_courses: "Мої курси",
            link_all: "Всі курси →",
            link_calendar: "Календар",
            today: "Сьогодні",
            title_announcements: "Оголошення",
            link_announcements: "Всі оголошення",
            empty_announcements: "Немає нових оголошень",
            not_available: "Н/Д",
            stat_active: "Активних курсів",

            // ТІЛЬКИ СТУДЕНТ
            student_status_info: "Ви навчаєтесь у групі",
            stat_completed: "Виконано завдань",
            stat_grade: "Середній бал",
            stat_coins: "Монети",
            title_deadlines: "Дедлайни",
            empty_courses_student: "Ви ще не записані на жоден курс.",
            empty_deadlines: "Активних дедлайнів немає",
            label_general: "Загальне",

            // ТІЛЬКИ ВИКЛАДАЧ
            stat_students: "Студентів",
            stat_grading: "На перевірці",
            stat_rating: "Рейтинг",
            title_schedule: "Розклад на сьогодні",
            title_grading_list: "Черга перевірки",
            link_grading: "Перевірити →",
            teacher_status_info: "Викладає на: ",
            no_classes_today: "Пар на сьогодні немає",
            all_graded: "Всі роботи перевірено",
            empty_courses_teacher: "Ви ще не ведете жоден курс",
            pending_submissions: "Роботи чекають на перевірку",
            items: "шт."
        },
        teacher_courses: {
            page_title: "Мої курси",
            page_desc: "Тут відображаються курси, які ви викладаєте, кількість студентів, завдань та середній прогрес груп.",

            stat_courses: "Курсів",
            stat_students: "Студентів",
            stat_tasks: "Завдань",
            stat_progress: "Середній прогрес",

            search_placeholder: "Пошук курсу...",

            sort_default: "За замовчуванням",
            sort_progress_desc: "Прогрес: спадання",
            sort_progress_asc: "Прогрес: зростання",
            sort_students_desc: "Більше студентів",
            sort_tasks_desc: "Більше завдань",

            students_label: "студентів",
            tasks_label: "завдань",
            open_btn: "Відкрити",

            untitled_course: "Курс без назви",
            no_description: "Опис курсу поки не додано.",

            empty_title: "Курсів не знайдено",
            empty_text: "Спробуйте змінити пошук або перевірте, чи вам призначені курси.",
            nav_grading: "📝 Перевірка",
            nav_profile: "👤 Профіль",
            unavailable_title: "Курси недоступні",
            unavailable_text: "Не вдалося завантажити курси."
            
        },
        teacher_course_detail: {
            course_label: "Курс викладача",

            attendance_title: "Відвідуваність",
            attendance_open: "Відкрити відвідуваність",
            no_attendance_preview: "Найближчих занять для відмітки поки немає.",
            attendance_open_status: "Відмітка відкрита",
            attendance_closed_status: "Відмітка закрита",

            avg_progress: "Середній прогрес",
            students_count: "Студентів",
            tasks_count: "Завдань",
            materials_count: "Матеріалів",

            tasks_title: "Завдання курсу",
            students_title: "Студенти курсу",
            materials_title: "Матеріали курсу",

            progress_label: "прогрес",

            no_tasks: "Завдання для цього курсу поки не додані.",
            no_students: "Студентів на цьому курсі поки немає.",
            no_materials: "Матеріали для цього курсу поки не додані.",
            checked_submissions: "Перевірено",
            no_submissions_status: "Немає робіт",
            needs_grading_status: "Очікує перевірки",

            unknown_student: "Невідомий студент",

            not_found_title: "Курс не знайдено",
            not_found_text: "Поверніться на сторінку курсів і відкрийте курс ще раз.",

            unavailable_title: "Деталі курсу недоступні",
            unavailable_text: "Не вдалося завантажити деталі курсу.",

            edit_tasks: "Редагувати",
            done: "Готово",
            create_task: "+ Створити",
            create_task_btn: "Створити завдання",

            title_uk: "Назва українською",
            title_en: "Назва англійською",
            description_uk: "Опис українською",
            description_en: "Опис англійською",
            exam_task: "Екзаменаційне завдання",

            no_task_description: "Опис завдання відсутній.",
            hide_task: "Сховати завдання",
            show_task: "Показати завдання",
            hidden_status: "Сховано",

            task_created_success: "Завдання створено",
            task_create_error: "Не вдалося створити завдання",
            task_hidden_success: "Завдання сховано",
            task_restored_success: "Завдання повернуто",
            task_visibility_error: "Не вдалося змінити видимість завдання",

            edit_materials: "Редагувати",
            create_material: "+ Додати",
            create_material_btn: "Додати матеріал",

            material_title_uk: "Назва матеріалу українською",
            material_title_en: "Назва матеріалу англійською",
            material_url: "Посилання на матеріал",
            material_type: "Тип матеріалу",

            hide_material: "Сховати матеріал",
            show_material: "Показати матеріал",

            material_created_success: "Матеріал додано",
            material_create_error: "Не вдалося додати матеріал",
            material_hidden_success: "Матеріал сховано",
            material_restored_success: "Матеріал повернуто",
            material_visibility_error: "Не вдалося змінити видимість матеріалу"
        },
        teacher_attendance: {
            page_label: "Відвідуваність",
            page_title: "Відвідуваність курсу",
            page_desc: "Тут можна переглядати заняття курсу та відкривати або закривати відмітку відвідуваності для студентів.",
            lessons_count: "Занять",
            present_count: "Присутніх",
            absent_count: "Відсутніх",
            attendance_percent: "Відвідуваність",
            search_placeholder: "Пошук за групою, датою або аудиторією...",
            filter_all: "Усі заняття",
            filter_open: "Відмітка відкрита",
            filter_closed: "Відмітка закрита",
            filter_completed: "Завершені заняття",
            status_open: "Відмітка відкрита",
            status_closed: "Відмітка закрита",
            no_group: "Групу не вказано",
            no_room: "Аудиторію не вказано",
            students_short: "студ.",
            open_btn: "Відкрити відмітку",
            close_btn: "Закрити відмітку",
            saving: "Збереження...",
            open_success: "Відмітку відкрито",
            close_success: "Відмітку закрито",
            update_error: "Не вдалося оновити статус відмітки",
            empty_title: "Занять не знайдено",
            empty_text: "Спробуйте змінити фільтр або пошуковий запит.",
            unavailable_title: "Відвідуваність недоступна",
            unavailable_text: "Не вдалося завантажити відвідуваність з backend.",
            no_course_title: "Курс не знайдено",
            no_course_text: "Поверніться на сторінку курсу і відкрийте відвідуваність ще раз.",
            show_details_btn: "Детальніше",
            hide_details_btn: "Сховати",
            present_students_title: "Студенти, які відмітились",
            no_present_students: "Поки що ніхто не відмітився.",
            marked_at: "Відмічено"
        },
        teacher_task_detail: {
            course_label: "Курс",
            edit: "Редагувати",
            cancel: "Скасувати",
            save: "Зберегти зміни",

            hidden: "🙈 Сховано",
            visible: "👁️ Видиме",
            exam: "📝 Екзаменаційне",
            submissions_count: "робіт",
            graded_count: "перевірено",

            submissions_title: "Роботи студентів",
            no_submissions: "Поки що немає зданих робіт.",
            submitted_at: "Здано",
            graded: "Оцінено",
            pending: "Очікує перевірки",

            load_error_title: "Не вдалося завантажити завдання",
            load_error_text: "Спробуйте оновити сторінку.",
            not_found_title: "Завдання не знайдено",
            not_found_text: "Некоректний ідентифікатор завдання.",
            update_success: "Завдання оновлено",
            update_error: "Не вдалося оновити завдання"
        },
        teacher_submissions: {
            page_title: "Перевірка робіт",
            page_desc: "Тут відображаються роботи студентів, які очікують оцінювання або вже були оцінені.",

            stat_total: "Усього робіт",
            stat_pending: "Очікують",
            stat_graded: "Оцінені",

            search_placeholder: "Пошук за студентом, курсом або завданням...",

            filter_all: "Усі",
            filter_pending: "Очікують",
            filter_graded: "Оцінені",

            status_pending: "Очікує перевірки",
            status_graded: "Оцінено",

            filter_course_all: "Усі курси",
            filter_task_all: "Усі завдання",

            student: "Студент",
            email: "Електронна пошта",
            submitted_at: "Здано",
            work_content: "Вміст роботи",
            file: "Файл",
            open_file: "Відкрити файл",
            no_file: "Файл не додано",
            no_content: "Текст роботи не додано",

            feedback: "Коментар",
            feedback_placeholder: "Напишіть коментар для студента...",
            grade_btn: "Оцінити",
            update_grade: "Оновити оцінку",
            saving: "Збереження...",
            grade_saved: "Оцінку збережено.",
            grade_error: "Не вдалося зберегти оцінку.",
            invalid_grade: "Оцінка має бути числом від 0 до 100.",

            empty_title: "Робіт не знайдено",
            empty_text: "Спробуйте змінити фільтр або пошуковий запит.",

            unavailable_title: "Роботи недоступні",
            unavailable_text: "Не вдалося завантажити роботи."
        },
        teacher_schedule: {
            page_title: "Розклад",
            page_desc: "Тут відображаються заняття, які ви проводите, групи, аудиторії та статус відмітки відвідування.",

            week_label: "Тиждень",

            stat_lessons: "Занять",
            stat_offline: "Офлайн",
            stat_online: "Онлайн",
            stat_open: "Відмітка відкрита",

            lessons_count: "заняття",
            no_room: "Аудиторію не вказано",

            today_title: "Сьогодні",
            loading_today: "Завантаження...",
            no_group: "Групу не вказано",
            attendance_open: "Відкрита",
            attendance_closed: "Закрита",

            format_online: "Онлайн",
            format_offline: "Офлайн",
            format_hybrid: "Змішано",

            attendance_open: "Відмітка відкрита",
            attendance_closed: "Відмітка закрита",

            empty_title: "Занять не знайдено",
            empty_text: "На цьому тижні у вас немає занять.",

            unavailable_title: "Розклад недоступний",
            unavailable_text: "Не вдалося завантажити розклад."
        },
        teacher_profile: {
            unknown_teacher: "Невідомий викладач",
            since: "з",

            stat_courses: "Активних курсів",
            stat_students: "Студентів",
            stat_pending: "На перевірці",
            stat_graded: "Оцінено робіт",

            info_title: "Особиста інформація",
            full_name: "ПІБ",
            title: "Посада",
            department: "Кафедра",
            rating: "Рейтинг",
            registration_year: "Рік реєстрації",

            courses_title: "Курси викладача",
            progress_label: "прогрес",
            no_courses: "Курси викладача не знайдені.",

            unavailable_title: "Профіль недоступний",
            unavailable_text: "Не вдалося завантажити профіль викладача."
        },
        courses: {
            page_title: "Мої курси",
            page_desc: "Тут зібрані всі курси, на які ви записані. Можна переглядати прогрес та переходити до навчання.",
            search_placeholder: "Пошук за назвою курсу...",
            filter_all: "Усі курси",
            filter_active: "Активні",
            filter_completed: "Завершені",
            filter_new: "Нові",
            progress: "Прогрес",
            open_btn: "Відкрити",
            status_active: "Активний",
            status_completed: "Завершений",
            status_new: "Новий",
            no_enrolled_title: "Навчання ще не почалося",
            empty_title: "Нічого не знайдено",
            empty_text: "За вашим запитом або фільтром немає відповідних курсів. Спробуйте змінити параметри пошуку."
        },
        course_detail: {
            progress: "Прогрес курсу",
            tasks_count: "Завдань",
            average_grade: "Середній бал",

            tasks_title: "Завдання курсу",
            materials_title: "Матеріали",
            attendance_title: "Відвідуваність",

            no_description: "Опис курсу поки не додано.",
            no_tasks: "Завдання для цього курсу поки не додані.",
            no_materials: "Матеріали курсу поки не додані.",
            no_attendance: "Позначок відвідування поки немає.",
            no_deadline: "Дедлайн не вказано",
            view_all_attendance: "Уся історія",

            attendance_present: "Присутній",
            attendance_absent: "Немає позначки",
            mark_attendance: "Позначити",
            marking: "Позначаємо...",
            attendance_marked: "Відвідування позначено.",

            material_lecture: "Лекція / конспект",
            material_manual: "Методичні вказівки",
            material_video: "Відео",
            material_link: "Посилання",
            material_book: "Книга",
            material_other: "Інше",
            materials_count: "матеріал(и)",

            lesson_lecture: "Лекція",
            lesson_practical: "Практичне заняття",
            lesson_seminar: "Семінар",
            lesson_exam: "Іспит",
            lesson_consultation: "Консультація",

            not_found_title: "Курс не знайдено",
            not_found_text: "Поверніться на сторінку курсів і виберіть курс ще раз.",
            unavailable_title: "Деталі курсу недоступні",
            unavailable_text: "Не вдалося завантажити деталі курсу."
        },
        attendance_page: {
            page_title: "Відвідуваність",
            page_desc: "Тут відображається повна історія ваших занять, присутності та доступних відміток по обраному курсу.",

            stat_total: "Усього занять",
            stat_present: "Присутній",
            stat_absent: "Без позначки",
            stat_percent: "Відсоток присутності",

            list_title: "Історія занять",
            empty_text: "Історія відвідуваності для цього курсу поки порожня.",
            no_room: "Аудиторію не вказано",

            not_found_title: "Курс не знайдено",
            not_found_text: "Поверніться на сторінку курсу та відкрийте історію відвідуваності ще раз.",

            unavailable_title: "Відвідуваність недоступна",
            unavailable_text: "Не вдалося завантажити історію відвідуваності"
        },
        task_detail: {
            no_deadline: "Дедлайн не вказано",

            not_found_title: "Завдання не знайдено",
            not_found_text: "Поверніться до курсу або сторінки завдань і виберіть завдання ще раз.",

            unavailable_title: "Деталі завдання недоступні",
            unavailable_text: "Не вдалося завантажити деталі завдання.",

            no_description: "Опис завдання поки не додано.",
            not_submitted: "Ще не здано",

            submission_status: "Дата здачі",
            description_title: "Опис завдання",
            result_title: "Результат",
            feedback: "Коментар вчителя",
            no_feedback: "Коментаря поки немає",
            submitted_at: "Дата здачі",

            submission_title: "Ваша робота",
            submit_title: "Здати роботу",
            submitted_file: "Прикріплений файл",
            download_file: "Завантажити файл",
            submission_comment: "Коментар до роботи",
            no_submission_comment: "Коментар не додано",
            drop_file: "Перетягніть або виберіть файл",
            no_file_selected: "Файл не вибрано",
            comment_placeholder: "Коментар до роботи...",
            submit_btn: "Надіслати роботу",
            submitting: "Надсилаємо...",
            submission_success: "Роботу успішно надіслано",
            no_file_uploaded: "Файл не прикріплено",

            edit_submission_btn: "Редагувати роботу",
            edit_submission_title: "Редагувати роботу",
            current_file: "Поточний файл",
            choose_new_file: "Виберіть новий файл",
            save_submission_btn: "Зберегти зміни"
        },
        tasks: {
            page_title: "Завдання",
            page_desc: "Тут відображаються ваші навчальні завдання, дедлайни, статус виконання та оцінки.",

            search_placeholder: "Пошук завдання...",
            filter_all: "Усі завдання",
            filter_pending: "Очікують",
            filter_submitted: "Здані",
            filter_graded: "Оцінені",
            filter_overdue: "Прострочені",

            stat_total: "Усього завдань",
            stat_pending: "Очікують виконання",
            stat_completed: "Виконано",
            stat_avg: "Середня оцінка",

            status_pending: "Очікує",
            status_submitted: "Здано",
            status_graded: "Оцінено",
            status_overdue: "Прострочено",

            deadline: "Дедлайн",
            grade: "Оцінка",
            no_grade: "Немає",
            open_btn: "Відкрити",

            empty_title: "Завдань не знайдено",
            empty_text: "Спробуйте змінити пошук або фільтр.",

            unknown_task: "Завдання без назви",
            course_not_specified: "Курс не вказано",
            no_deadline: "Дедлайн не вказано",
            exam: "Іспит"
        },
        schedule: {
            page_title: "Розклад занять",
            page_desc: "Тут відображаються ваші заняття на тиждень, час проведення, аудиторія та формат навчання.",
            prev_week: "← Попередній",
            next_week: "Наступний →",
            current_week: "Поточний тиждень",
            today_title: "Сьогодні",
            monday: "Понеділок",
            tuesday: "Вівторок",
            wednesday: "Середа",
            thursday: "Четвер",
            friday: "П’ятниця",
            saturday: "Субота",
            sunday: "Неділя",
            teacher: "Викладач",
            room: "Ауд.",
            empty_day: "Занять немає",
            empty_today: "На сьогодні занять більше немає.",
            unknown_lesson: "Заняття без назви",
            format_online: "Онлайн",
            format_offline: "Оффлайн",
            type_lecture: "Лекція",
            type_practical: "Практика",
            type_seminar: "Семінар",
            type_exam: "Іспит",
            type_consultation: "Консультація"
        },
        grades: {
            page_title: "Оцінки",
            page_desc: "Тут зібрана ваша академічна успішність, оцінки за завдання, середній бал та прогрес по курсах.",

            stat_avg: "Середній бал",
            stat_graded: "Оцінено робіт",
            stat_courses: "Курсів",
            stat_best: "Найкраща оцінка",

            search_placeholder: "Пошук за курсом, завданням або коментарем...",
            filter_all: "Усі курси",

            table_title: "Журнал оцінок",
            side_title: "Успішність по курсах",

            th_course: "Курс",
            th_task: "Завдання",
            th_date: "Дата",
            th_grade: "Оцінка",
            th_status: "Статус",

            status_passed: "Зараховано",
            status_pending: "Очікується",
            status_failed: "Не зараховано",

            no_grade: "Немає",
            course_not_specified: "Курс не вказано",
            task_not_specified: "Завдання не вказано",

            empty_title: "Оцінок не знайдено",
            empty_text: "Спробуйте змінити пошук або фільтр."
        },
        profile: {
            loading: "Завантаження...",
            course_suffix: "курс",
            btn_edit: "✏️ Редагувати",
            btn_share: "🤝 Поділитись",
            stat_avg: "Середній бал",
            stat_courses: "Активних курсів",
            stat_tasks: "Завдань здано",
            stat_attendance: "Відвідуваність",
            stat_coins: "Монети",
            stat_achievements: "Досягнень",
            tab_overview: "Огляд",
            tab_grades: "Оцінки",
            tab_achievements: "Досягнення",
            tab_activity: "Активність",
            tab_settings: "Налаштування",
            card_courses: "📚 Поточні курси",
            card_achievements: "🏆 Останні досягнення",
            card_activity: "📊 Активність за тиждень",
            card_skills: "🧠 Навички",
            card_deadlines: "⏰ Найближчі дедлайни",
            link_all: "Всі →",
            empty_achievements: "У вас поки немає відкритих досягнень",
            empty_skills: "Навички з'являться після проходження курсів",
            submissions_count: "Зданих робіт",

            card_grades_full: "🎓 Повна академічна успішність",
            th_course: "Курс",
            th_task: "Завдання",
            th_date: "Дата",
            th_grade: "Оцінка",
            settings_security: "🛡️ Безпека та доступ",
            label_old_password: "Поточний пароль",
            label_new_password: "Новий пароль",
            btn_update_password: "Оновити пароль",
            settings_preferences: "⚙️ Переваги інтерфейсу",
            settings_lang_hint: "Мову та тему можна змінити у бічній панелі швидкого доступу.",
            password_updated_success: "Пароль успішно оновлено!",
            tab_activity_full: "📜 Історія останніх подій",
            event_grade: "Оцінка",
            achievements_list_tab: "🏆Досягнення",
            event_achievement: "Досягнення",
            empty_history: "Подій ще не зафіксовано",
            link_copied: "Посилання на профіль скопійовано"
        },
        notifications: {
            title: "Сповіщення",
            subtitle: "Ваші особисті повідомлення",
            list_title: "Усі сповіщення",
            stat_total: "Усього",
            stat_unread: "Непрочитані",
            stat_read: "Прочитані",
            search_placeholder: "Пошук сповіщень...",
            filter_all: "Усі",
            filter_unread: "Непрочитані",
            filter_read: "Прочитані",
            empty: "Сповіщень поки немає",
            read: "Прочитано",
            unread: "Нове",
            mark_read: "Позначити як прочитане",
            mark_all_read: "Позначити всі як прочитані"
        },
        announcements: {
            title: "Оголошення",
            subtitle: "Усі важливі повідомлення курсів та платформи",
            list_title: "Усі оголошення",
            stat_total: "Усього",
            stat_unread: "Непрочитані",
            stat_read: "Прочитані",
            search_placeholder: "Пошук оголошень...",
            filter_all: "Усі",
            filter_unread: "Непрочитані",
            filter_read: "Прочитані",
            mark_all: "Позначити всі як прочитані",
            empty: "Оголошень поки немає",
            create_btn: "+ Створити оголошення",
            create_modal_title: "Створити оголошення",
            create_modal_desc: "Заповніть дані оголошення.",
            course: "Курс",
            course_all: "Для всіх",
            title_uk: "Заголовок українською",
            title_en: "Заголовок англійською",
            content_uk: "Текст українською",
            content_en: "Текст англійською",
            title_uk_placeholder: "Наприклад, Оновлення платформи",
            title_en_placeholder: "For example, Platform update",
            content_uk_placeholder: "Введіть текст оголошення українською...",
            content_en_placeholder: "Enter announcement text in English...",
            create_submit: "Створити",
            create_success: "Оголошення створено.",
            create_error: "Не вдалося створити оголошення.",
            fields_required: "Заповніть усі поля оголошення.",
            courses_load_error: "Не вдалося завантажити курси.",
            course_required_for_teacher: "Викладач повинен обрати курс.",
            no_courses_available: "Немає доступних курсів."
        },
        moderator_nav: {
             dashboard: "🛡️ Панель",
            users: "👥 Користувачі",
            courses: "📚 Курси",
            activity: "📌 Активність"
        },
        moderator_dashboard: {
            badge: "MODERATOR",
            title: "Панель модератора",
            desc: "Загальний огляд стану освітньої платформи Mooden: користувачі, курси, завдання, активність і системні події.",

            stat_users: "Користувачів",
            stat_courses: "Курсів",
            stat_tasks: "Завдань",
            stat_submissions: "Зданих робіт",

            stat_students: "Студентів",
            stat_teachers: "Викладачів",
            stat_announcements: "Оголошень",
            stat_attendance: "Відкритих відміток",

            quick_actions: "Швидкі дії",

            users_title: "Користувачі",
            users_text: "Перегляд користувачів і зміна ролей.",

            courses_title: "Курси",
            courses_text: "Перегляд курсів, студентів і завдань.",

            activity_title: "Активність",
            activity_text: "Останні дії користувачів у системі.",

            announcements_title: "Оголошення",
            announcements_text: "Перегляд доступних оголошень платформи.",

            recent_activity: "Остання активність",
            recent_announcements: "Останні оголошення",

            view_all: "Переглянути всі",
            all: "Усі",

            loading: "Завантаження...",

            no_activity: "Активності поки немає.",
            no_announcements: "Нових оголошень поки немає.",

            submission_default: "Здана робота",
            student_default: "Студент",
            course_default: "Курс",

            general: "Загальне",
            announcement_default: "Оголошення без назви",
            author: "Автор",

            activity_error: "Не вдалося завантажити активність.",
            announcements_error: "Не вдалося завантажити оголошення.",
            load_error: "Не вдалося завантажити панель модератора."
        },

        moderator_users: {
            badge: "MODERATOR",
            title: "Користувачі",
            desc: "На цій сторінці модератор може переглядати користувачів системи, фільтрувати їх за ролями, редагувати дані, змінювати роль, блокувати або розблоковувати облікові записи.",

            add_user: "+ Додати користувача",

            stat_total: "Усього",
            stat_students: "Студентів",
            stat_teachers: "Викладачів",
            stat_blocked: "Заблоковано",

            search_placeholder: "Пошук за ім’ям або email...",

            all_roles: "Усі ролі",
            students: "Студенти",
            teachers: "Викладачі",
            moderators: "Модератори",

            all_statuses: "Усі статуси",
            active_users: "Активні",
            blocked_users: "Заблоковані",

            loading_title: "Завантаження...",
            loading_text: "Отримуємо список користувачів.",

            empty_title: "Користувачів не знайдено",
            empty_text: "Спробуйте змінити фільтр або пошуковий запит.",

            no_access_title: "Немає доступу",
            no_access_text: "Потрібно авторизуватися.",

            load_error_title: "Не вдалося завантажити користувачів",
            load_error_text: "Перевірте підключення або повторіть спробу пізніше.",

            role: "Роль",

            role_student: "Студент",
            role_teacher: "Викладач",
            role_moderator: "Модератор",

            active: "Активний",
            blocked: "Заблоковано",

            unknown_user: "Невідомий користувач",
            no_email: "Email не вказано",

            edit: "Редагувати",
            ban: "Забанити",
            unban: "Розбанити",

            role_updated: "Роль користувача оновлено.",
            role_update_error: "Не вдалося змінити роль користувача.",

            ban_success: "Користувача заблоковано.",
            unban_success: "Користувача розблоковано.",
            ban_error: "Не вдалося оновити статус користувача.",

            add_modal_title: "Додати користувача",
            add_modal_desc: "Заповніть дані нового користувача.",

            edit_modal_title: "Редагувати користувача",
            edit_modal_desc: "Оновіть основні дані облікового запису.",

            full_name: "ПІБ",
            full_name_placeholder: "Наприклад, Іваненко Іван Іванович",

            lang: "Мова",

            password: "Пароль",
            password_placeholder: "Пароль для нового користувача",

            cancel: "Скасувати",
            save: "Зберегти",

            create_success: "Користувача створено.",
            update_success: "Дані користувача оновлено.",
            save_error: "Не вдалося зберегти дані користувача.",
            full_name_required: "Вкажіть повне ім'я користувача.",
            email_required: "Вкажіть email користувача.",
            password_too_short: "Пароль має містити мінімум 6 символів.",
            email_already_exists: "Користувач з таким email вже існує."
        },

        moderator_courses: {
            badge: "MODERATOR",
            title: "Курси",
            desc: "На цій сторінці модератор може переглядати курси платформи, редагувати їхні основні дані, зараховувати студентів і призначати викладачів.",

            add_course: "+ Додати курс",

            stat_courses: "Курсів",
            stat_students: "Зарахувань студентів",
            stat_teachers: "Призначень викладачів",
            stat_tasks: "Завдань",

            search_placeholder: "Пошук курсу...",
            sort_title: "За назвою",
            sort_students: "За кількістю студентів",
            sort_teachers: "За кількістю викладачів",
            sort_tasks: "За кількістю завдань",

            loading_title: "Завантаження...",
            loading_text: "Отримуємо список курсів.",

            empty_title: "Курсів не знайдено",
            empty_text: "Спробуйте змінити пошук або сортування.",

            no_access_title: "Немає доступу",
            no_access_text: "Потрібно авторизуватися.",

            load_error_title: "Не вдалося завантажити курси",
            load_error_text: "Перевірте підключення або повторіть спробу пізніше.",

            untitled: "Курс без назви",
            active: "Активний",
            hidden: "Прихований",
            no_description: "Опис курсу не вказано.",

            students: "студентів",
            teachers: "викладачів",
            tasks: "завдань",

            edit: "Редагувати",
            members: "Учасники",
            hide_course: "Сховати",
            show_course: "Показати",

            add_modal_title: "Додати курс",
            add_modal_desc: "Заповніть основну інформацію про новий курс.",

            edit_modal_title: "Редагувати курс",
            edit_modal_desc: "Оновіть основну інформацію про курс.",

            title_uk: "Назва українською",
            title_en: "Назва англійською",
            desc_uk: "Опис українською",
            desc_en: "Опис англійською",
            color: "Колір курсу",

            cancel: "Скасувати",
            save: "Зберегти",

            members_title: "Учасники курсу",
            members_desc: "Керуйте студентами та викладачами, пов’язаними з курсом.",
            course_students: "Студенти курсу",
            course_teachers: "Викладачі курсу",

            add_student: "Зарахувати",
            add_teacher: "Призначити",
            remove_student: "Відрахувати",
            remove_teacher: "Прибрати",

            students_empty: "Студентів ще не зараховано.",
            teachers_empty: "Викладачів ще не призначено.",
            no_available_students: "Немає доступних студентів",
            no_available_teachers: "Немає доступних викладачів",

            student_default: "Студент",
            teacher_default: "Викладач",

            choose_student: "Оберіть студента.",
            choose_teacher: "Оберіть викладача.",

            create_success: "Курс створено.",
            update_success: "Курс оновлено.",
            save_error: "Не вдалося зберегти курс.",

            hide_success: "Курс приховано.",
            show_success: "Курс показано.",
            visibility_error: "Не вдалося змінити видимість курсу.",

            members_error: "Не вдалося завантажити учасників курсу.",

            add_student_success: "Студента зараховано на курс.",
            remove_student_success: "Студента відраховано з курсу.",
            add_teacher_success: "Викладача призначено на курс.",
            remove_teacher_success: "Викладача прибрано з курсу.",

            add_student_error: "Не вдалося зарахувати студента.",
            remove_student_error: "Не вдалося відрахувати студента.",
            add_teacher_error: "Не вдалося призначити викладача.",
            remove_teacher_error: "Не вдалося прибрати викладача."
        },

        moderator_activity: {
            badge: "MODERATOR",
            title: "Активність",
            desc: "На цій сторінці модератор може переглядати останні дії користувачів у системі: здачу робіт, оголошення, події курсів та інші зміни.",
            refresh: "Оновити",

            stat_total: "Усього подій",
            stat_submissions: "Здані роботи",
            stat_announcements: "Оголошення",
            stat_attendance: "Відвідуваність",

            search_placeholder: "Пошук за студентом, курсом або назвою...",
            filter_all: "Усі типи",
            filter_submissions: "Здані роботи",
            filter_announcements: "Оголошення",
            filter_attendance: "Відвідуваність",
            filter_notifications: "Сповіщення",
            filter_system: "Системні події",

            sort_newest: "Спочатку нові",
            sort_oldest: "Спочатку старі",

            loading_title: "Завантаження...",
            loading_text: "Отримуємо активність системи.",
            empty_title: "Активності не знайдено",
            empty_text: "Спробуйте змінити пошук або фільтр.",
            no_access_title: "Немає доступу",
            no_access_text: "Потрібно авторизуватися як модератор.",
            load_error_title: "Не вдалося завантажити активність",
            load_error_text: "Перевірте backend або права доступу модератора.",

            type_submission: "Здана робота",
            type_announcement: "Оголошення",
            type_attendance: "Відвідуваність",
            type_notification: "Сповіщення",
            type_default: "Активність",

            default_title: "Подія без назви",
            submitted_work: "Здана робота",
            student: "Студент",
            course: "Курс",

            desc_submission: "Здано роботу",
            desc_announcement: "Створено або опубліковано оголошення",
            desc_attendance: "Студент відмітив присутність на занятті.",
            desc_notification: "Створено системне сповіщення.",
            desc_default: "Зафіксовано подію в системі.",

            refreshed: "Активність оновлено.",
            load_error: "Не вдалося завантажити активність."
        },
        moderator_profile: {
            role_badge: "Профіль модератора",
            sub_info: "Модератор системи",
            role_tag: "🛡️ moderator",

            stat_users: "Користувачів",
            stat_courses: "Курсів",
            stat_announcements: "Оголошень",
            stat_attendance: "Відкритих відміток",

            info_title: "Особиста інформація",
            full_name: "ПІБ",
            role: "Роль",
            role_value: "Модератор",
            lang: "Мова інтерфейсу",

            permissions_title: "Зона відповідальності",
            permission_users_title: "Користувачі",
            permission_users_text: "Перегляд користувачів, редагування даних, зміна ролей, блокування та розблокування облікових записів.",
            permission_courses_title: "Курси",
            permission_courses_text: "Перегляд курсів, редагування інформації, зарахування студентів і призначення викладачів.",
            permission_activity_title: "Активність",
            permission_activity_text: "Перегляд зданих робіт, оголошень, відвідуваності та сповіщень у системі.",
            permission_communication_title: "Комунікація",
            permission_communication_text: "Перегляд оголошень і сповіщень, пов’язаних з роботою освітньої платформи.",

            edit_title: "✏️ Редагування профілю",
            btn_update_profile: "Оновити профіль",

            fallback_name: "Модератор",
            no_email: "Email не вказано",
            validation_error: "Заповніть ПІБ та email.",
            update_success: "Профіль оновлено.",
            update_error: "Не вдалося оновити профіль модератора.",
            unavailable_title: "Профіль недоступний",
            unavailable_text: "Не вдалося завантажити профіль модератора."
        },
        errors: {
            USER_BLOCKED: "Ваш акаунт заблоковано.",
            INVALID_CREDENTIALS: "Невірний email або пароль.",
            SERVER_ERROR: "Помилка сервера. Спробуйте пізніше.",
            UNAUTHORIZED: "Ви не авторизовані. Повертаємо на сторінку входу...",
            ACCESS_DENIED: "Ця сторінка лише для {role}.",
            ROLE_ERROR: "Ваша роль не розпізнана системою.",
            INVALID_TOKEN: "Сесія застаріла. Будь ласка, увійдіть знову.",
            USER_NOT_FOUND: "Користувача не знайдено",
            EMAIL_REQUIRED: "Вкажіть email.",
            RESET_TOKEN_REQUIRED: "Токен відновлення відсутній.",
            RESET_TOKEN_EXPIRED: "Посилання для відновлення пароля недійсне або строк його дії минув.",
            RESET_TOKEN_VERIFY_ERROR: "Не вдалося перевірити посилання відновлення.",
            PASSWORDS_DO_NOT_MATCH: "Паролі не збігаються.",
            PASSWORD_RESET_REQUEST_ERROR: "Не вдалося надіслати лист для відновлення пароля.",
            PASSWORD_RESET_ERROR: "Не вдалося оновити пароль.",
            SERVER_ERROR_DASHBOARD: "Не вдалося завантажити дані панелі.",
            SERVER_ERROR_PROFILE: "Не вдалося завантажити дані профілю",
            ERROR_MARK_READ: "Не вдалося позначити оголошення як прочитане.",
            ERROR_UPDATE_SETTINGS: "Помилка при зміні мови.",
            UNKNOWN_ERROR: "Щось пішло не так. Спробуйте пізніше.",
            NETWORK_ERROR: "Не вдалося з’єднатися з сервером.",
            SIDEBAR_ERROR: "Помилка завантаження бічного меню",
            WRONG_OLD_PASSWORD: "Поточний пароль введено невірно.",
            PASSWORD_UPDATE_ERROR: "Не вдалося оновити пароль.",
            PASSWORD_FIELDS_REQUIRED: "Заповніть поточний та новий пароль.",
            PASSWORD_TOO_SHORT: "Новий пароль має містити мінімум 6 символів.",
            COPY_ERROR: "Не вдалося скопіювати посилання.",
            SERVER_ERROR_COURSES: "Не вдалося завантажити список курсів.",
            SERVER_ERROR_TASKS: "Не вдалося завантажити список завдань.",
            SERVER_ERROR_SCHEDULE: "Не вдалося завантажити розклад занять.",

            TASK_NOT_FOUND: "Завдання не знайдено або доступ заборонено.",
            SERVER_ERROR_TASK_DETAIL: "Не вдалося завантажити інформацію про завдання.",
            ATTENDANCE_CLOSED: "Час для відмітки на цій парі вичерпано або викладач закрив доступ.",
            ATTENDANCE_ERROR: "Сталася помилка при спробі відмітитися.",
            COURSE_NOT_FOUND: "Курс не знайдено або ви на нього не записані.",
            SERVER_ERROR_COURSE_DETAIL: "Не вдалося завантажити дані курсу.",
            SERVER_ERROR_ATTENDANCE: "Не вдалося завантажити історію відвідувань.",
            SUBMISSION_ALREADY_EXISTS: "Роботу вже здано.",
            SUBMISSION_ERROR: "Не вдалося надіслати роботу.",
            EMPTY_SUBMISSION: "Додайте файл або коментар до роботи.",
            SUBMISSION_COMMENT_TOO_LONG: "Коментар занадто довгий",
            NOTIFICATIONS_ERROR: "Не вдалося завантажити сповіщення.",
            NOTIFICATION_READ_ERROR: "Не вдалося оновити статус сповіщення.",
            ANNOUNCEMENT_FIELDS_REQUIRED: "Заповніть усі поля оголошення.",
            ANNOUNCEMENT_CREATE_ERROR: "Не вдалося створити оголошення.",
            COURSE_REQUIRED_FOR_TEACHER: "Викладач повинен обрати курс."
        }
    },
    en: {
        common: {
            nav_label_main: "NAVIGATION",
            nav_dashboard: "📊 Dashboard",
            nav_courses: "📖 My Courses",
            nav_tasks: "📝 Tasks",
            nav_schedule: "📅 Schedule",
            nav_grades: "⭐ Grades",
            nav_shop: "💎 Shop",
            nav_label_community: "COMMUNITY",
            nav_announcements: "📢 Announcements",
            nav_notifications: "🔔 Notifications",
            nav_profile: "👤 Profile",
            nav_discussions: "💬 Discussions",
            nav_grading: "📝 Grading",
            logout_btn: "🚪 Log Out",
            theme_dark: "Dark Mode",
            theme_light: "Light Mode",
            roles_for_redirect: {
                student: "Student",
                teacher: "Teacher",
                moderator: "Moderator"
            },
            roles: {
                student: "Student",
                teacher: "Teacher",
                moderator: "Moderator"
            },
            go_back: "Go Back",
            redirecting: " Redirecting to your panel...",
            nav_grading: "📝 Grading",
            nav_constructor: "🔧 Constructor",
            cancel: "Cancel"
        },
        login: {
            welcome_badge: "WELCOME BACK",
            hero_title: "Welcome back to learning",
            hero_subtitle: "Your courses, tasks and grades are waiting for you. Log in to continue.",
            stat_students: "Students",
            stat_courses: "Courses",
            stat_tasks: "Tasks",
            title: "Sign In",
            subtitle: "Enter your credentials",
            email_label: "EMAIL ADDRESS",
            password_label: "PASSWORD",
            forgot_link: "Forgot password?",
            remember_me: "Remember me",
            login_btn: "Log In →",
            no_account: "Don't have an account?",
            register_link: "Contact the administrator"
        },
        password_reset: {
            forgot_title: "Password recovery",
            forgot_subtitle: "Enter your email and we will send a password reset link.",
            send_link: "Send link",
            link_sent: "If an account with this email exists, we have sent a password reset email.",
            back_to_login: "Back to login",
            reset_title: "New password",
            reset_subtitle: "Enter a new password and confirm it.",
            new_password: "New password",
            confirm_password: "Confirm password",
            update_password: "Update password",
            password_updated: "Password updated successfully."
        },
        dashboard: {
            welcome: "Welcome",
            status_loading: "Fetching current information...",
            user_loading: "Loading...",
            title_courses: "My Courses",
            link_all: "All Courses →",
            link_calendar: "Calendar",
            today: "Today",
            empty_announcements: "No new announcements",
            not_available: "N/A",
            stat_active: "Active Courses",

            // STUDENT ONLY
            student_status_info: "You are studying in group",
            stat_completed: "Tasks Completed",
            stat_grade: "GPA",
            stat_coins: "Coins",
            title_deadlines: "Deadlines",
            title_announcements: "Announcements",
            link_announcements: "All Announcements",
            empty_courses_student: "No courses enrolled yet.",
            empty_deadlines: "No active deadlines",
            label_general: "General",

            // TEACHER ONLY
            stat_students: "Students",
            stat_grading: "Pending",
            stat_rating: "Rating",
            title_schedule: "Today's Schedule",
            title_grading_list: "Grading Queue",
            link_grading: "Check →",
            teacher_status_info: "Teaches at",
            no_classes_today: "No classes today",
            all_graded: "All items are graded",
            empty_courses_teacher: "You are not teaching any courses yet",
            pending_submissions: "Submissions waiting for review",
            items: "pcs."
        },
        teacher_courses: {
            page_title: "My Courses",
            page_desc: "Here you can view the courses you teach, the number of students, tasks and the average group progress.",

            stat_courses: "Courses",
            stat_students: "Students",
            stat_tasks: "Tasks",
            stat_progress: "Average progress",

            search_placeholder: "Search course...",

            sort_default: "Default order",
            sort_progress_desc: "Progress: descending",
            sort_progress_asc: "Progress: ascending",
            sort_students_desc: "More students",
            sort_tasks_desc: "More tasks",

            students_label: "students",
            tasks_label: "tasks",
            open_btn: "Open",

            untitled_course: "Untitled course",
            no_description: "The course description has not been added yet.",

            empty_title: "No courses found",
            empty_text: "Try changing the search query or check whether courses are assigned to you.",
            
            unavailable_title: "Courses are not available",
            unavailable_text: "Failed to load courses."
        },
        teacher_course_detail: {
            course_label: "Teacher course",
            attendance_title: "Attendance",
            attendance_open: "Open attendance",
            no_attendance_preview: "There are no upcoming attendance lessons yet.",
            attendance_open_status: "Attendance open",
            attendance_closed_status: "Attendance closed",

            avg_progress: "Average progress",
            students_count: "Students",
            tasks_count: "Tasks",
            materials_count: "Materials",

            tasks_title: "Course tasks",
            students_title: "Course students",
            materials_title: "Course materials",

            progress_label: "progress",

            no_tasks: "Tasks for this course have not been added yet.",
            no_students: "There are no students in this course yet.",
            no_materials: "Materials for this course have not been added yet.",
            checked_submissions: "Checked",
            no_submissions_status: "No submissions",
            needs_grading_status: "Needs grading",

            unknown_student: "Unknown student",

            not_found_title: "Course not found",
            not_found_text: "Please return to the courses page and open the course again.",

            unavailable_title: "Course details are not available",
            unavailable_text: "Failed to load course details.",

            edit_tasks: "Edit",
            done: "Done",
            create_task: "+ Create",
            create_task_btn: "Create task",

            title_uk: "Title in Ukrainian",
            title_en: "Title in English",
            description_uk: "Description in Ukrainian",
            description_en: "Description in English",
            exam_task: "Exam task",

            no_task_description: "Task description is missing.",
            hide_task: "Hide task",
            show_task: "Show task",
            hidden_status: "Hidden",

            task_created_success: "Task has been created",
            task_create_error: "Failed to create task",
            task_hidden_success: "Task has been hidden",
            task_restored_success: "Task has been restored",
            task_visibility_error: "Failed to update task visibility",

            edit_materials: "Edit",
            create_material: "+ Add",
            create_material_btn: "Add material",

            material_title_uk: "Material title in Ukrainian",
            material_title_en: "Material title in English",
            material_url: "Material link",
            material_type: "Material type",

            hide_material: "Hide material",
            show_material: "Show material",

            material_created_success: "Material has been added",
            material_create_error: "Failed to add material",
            material_hidden_success: "Material has been hidden",
            material_restored_success: "Material has been restored",
            material_visibility_error: "Failed to update material visibility"
        },
        teacher_attendance: {
            page_label: "Attendance",
            page_title: "Course attendance",
            page_desc: "Here you can view course lessons and open or close attendance marking for students.",
            lessons_count: "Lessons",
            present_count: "Present",
            absent_count: "Absent",
            attendance_percent: "Attendance",
            search_placeholder: "Search by group, date or room...",
            filter_all: "All lessons",
            filter_open: "Attendance open",
            filter_closed: "Attendance closed",
            filter_completed: "Completed lessons",
            status_open: "Attendance open",
            status_closed: "Attendance closed",
            no_group: "Group is not specified",
            no_room: "Room is not specified",
            students_short: "stud.",
            open_btn: "Open attendance",
            close_btn: "Close attendance",
            saving: "Saving...",
            open_success: "Attendance has been opened",
            close_success: "Attendance has been closed",
            update_error: "Failed to update attendance status",
            empty_title: "No lessons found",
            empty_text: "Try changing the filter or search query.",
            unavailable_title: "Attendance is not available",
            unavailable_text: "Failed to load attendance from backend.",
            no_course_title: "Course not found",
            no_course_text: "Return to the course page and open attendance again."
        },
        teacher_task_detail: {
            course_label: "Course",
            edit: "Edit",
            cancel: "Cancel",
            save: "Save changes",

            hidden: "🙈 Hidden",
            visible: "👁️ Visible",
            exam: "📝 Exam task",
            submissions_count: "submissions",
            graded_count: "graded",

            submissions_title: "Student submissions",
            no_submissions: "There are no submissions yet.",
            submitted_at: "Submitted",
            graded: "Graded",
            pending: "Pending review",

            load_error_title: "Failed to load task",
            load_error_text: "Try refreshing the page.",
            not_found_title: "Task not found",
            not_found_text: "Invalid task identifier.",
            update_success: "Task has been updated",
            update_error: "Failed to update task",
            show_details_btn: "Details",
            hide_details_btn: "Hide",
            present_students_title: "Students who checked in",
            no_present_students: "No students have checked in yet.",
            marked_at: "Marked at"
        },
        teacher_submissions: {
            page_title: "Submissions",
            page_desc: "Here you can view student submissions that are waiting for grading or have already been graded.",

            stat_total: "Total submissions",
            stat_pending: "Pending",
            stat_graded: "Graded",

            search_placeholder: "Search by student, course or task...",

            filter_all: "All",
            filter_pending: "Pending",
            filter_graded: "Graded",

            status_pending: "Pending review",
            status_graded: "Graded",

            filter_course_all: "All courses",
            filter_task_all: "All assignments",

            student: "Student",
            submitted_at: "Submitted",
            email: "Email",
            work_content: "Work content",
            file: "File",
            open_file: "Open file",
            no_file: "No file attached",
            no_content: "No text content submitted",

            feedback: "Feedback",
            feedback_placeholder: "Write feedback for the student...",
            grade_btn: "Grade",
            update_grade: "Update grade",
            saving: "Saving...",
            grade_saved: "Grade has been saved.",
            grade_error: "Failed to save grade.",
            invalid_grade: "Grade must be a number from 0 to 100.",

            empty_title: "No submissions found",
            empty_text: "Try changing the filter or search query.",

            unavailable_title: "Submissions are not available",
            unavailable_text: "Failed to load submissions."
        },
        teacher_schedule: {
            page_title: "Schedule",
            page_desc: "Here you can view the lessons you teach, groups, rooms and attendance marking status.",

            week_label: "Week",

            stat_lessons: "Lessons",
            stat_offline: "Offline",
            stat_online: "Online",
            stat_open: "Attendance open",

            lessons_count: "lessons",
            no_room: "Room is not specified",

            today_title: "Today",
            loading_today: "Loading...",
            no_group: "Group is not specified",
            attendance_open: "Open",
            attendance_closed: "Closed",

            format_online: "Online",
            format_offline: "Offline",
            format_hybrid: "Hybrid",

            attendance_open: "Attendance open",
            attendance_closed: "Attendance closed",

            empty_title: "No lessons found",
            empty_text: "You have no lessons this week.",

            unavailable_title: "Schedule is not available yet",
            unavailable_text: "Failed to load schedule from backend."
        },
        teacher_profile: {
            unknown_teacher: "Unknown teacher",
            since: "since",

            stat_courses: "Active courses",
            stat_students: "Students",
            stat_pending: "Pending grading",
            stat_graded: "Graded works",

            info_title: "Personal information",
            full_name: "Full name",
            title: "Title",
            department: "Department",
            rating: "Rating",
            registration_year: "Registration year",

            courses_title: "Teacher courses",
            progress_label: "progress",
            no_courses: "Teacher courses have not been found yet.",

            unavailable_title: "Profile is not available yet",
            unavailable_text: "Failed to load teacher profile from backend."
        },
        courses: {
            page_title: "My Courses",
            page_desc: "Here you can find all the courses you are enrolled in. You can view progress and continue learning.",
            search_placeholder: "Search by course name...",
            filter_all: "All courses",
            filter_active: "Active",
            filter_completed: "Completed",
            filter_new: "New",
            progress: "Progress",
            open_btn: "Open",
            status_active: "Active",
            status_completed: "Completed",
            status_new: "New",
            no_enrolled_title: "No courses yet",
            empty_title: "No results found",
            empty_text: "There are no courses matching your search or filter. Try adjusting your criteria."
        },
        task_detail: {
            no_deadline: "No deadline specified",

            not_found_title: "Task not found",
            not_found_text: "Please return to the course or tasks page and select a task again.",

            unavailable_title: "Task details are not available yet",
            unavailable_text: "Failed to load task details from backend.",

            no_description: "The task description has not been added yet.",
            not_submitted: "Not submitted yet",

            submission_status: "Submission date",
            description_title: "Task description",
            result_title: "Result",
            feedback: "Teacher`s feedback",
            no_feedback: "No feedback yet",
            submitted_at: "Submission date",

            submission_title: "Your submission",
            submit_title: "Submit work",
            submitted_file: "Attached file",
            download_file: "Download file",
            submission_comment: "Submission comment",
            no_submission_comment: "No comment added",
            drop_file: "Drag or choose a file",
            no_file_selected: "No file selected",
            comment_placeholder: "Comment for your work...",
            submit_btn: "Submit work",
            submitting: "Submitting...",
            submission_success: "Work submitted successfully",
            no_file_uploaded: "No file attached",

            edit_submission_btn: "Edit submission",
            edit_submission_title: "Edit submission",
            current_file: "Current file",
            choose_new_file: "Choose a new file",
            save_submission_btn: "Save changes"
        },
        course_detail: {
            progress: "Course progress",
            tasks_count: "Tasks",
            average_grade: "Average grade",

            tasks_title: "Course tasks",
            materials_title: "Materials",
            attendance_title: "Attendance",

            no_description: "The course description has not been added yet.",
            no_tasks: "Tasks for this course have not been added yet.",
            no_materials: "Course materials have not been added yet.",
            no_attendance: "There are no attendance marks yet.",
            no_deadline: "No deadline specified",
            view_all_attendance: "View all",

            attendance_present: "Present",
            attendance_absent: "No mark",
            mark_attendance: "Mark",
            marking: "Marking...",
            attendance_marked: "Attendance has been marked.",

            material_lecture: "Lecture / notes",
            material_manual: "Manual",
            material_video: "Video",
            material_link: "Link",
            material_book: "Book",
            material_other: "Other",
            materials_count: "material(s)",

            lesson_lecture: "Lecture",
            lesson_practical: "Practical class",
            lesson_seminar: "Seminar",
            lesson_exam: "Exam",
            lesson_consultation: "Consultation",

            not_found_title: "Course not found",
            not_found_text: "Please return to the courses page and select a course again.",
            unavailable_title: "Course details are not available yet",
            unavailable_text: "Failed to load course details from backend."
        },
        attendance_page: {
            page_title: "Attendance",
            page_desc: "Here you can view the full history of your lessons, attendance marks and available check-ins for the selected course.",

            stat_total: "Total lessons",
            stat_present: "Present",
            stat_absent: "No mark",
            stat_percent: "Attendance rate",

            list_title: "Lesson history",
            empty_text: "Attendance history for this course is empty yet.",
            no_room: "Room is not specified",

            not_found_title: "Course not found",
            not_found_text: "Please return to the course page and open the attendance history again.",

            unavailable_title: "Attendance is not available yet",
            unavailable_text: "Failed to load attendance history from backend."
        },
        tasks: {
            page_title: "Tasks",
            page_desc: "Here you can view your learning tasks, deadlines, completion statuses and grades.",

            search_placeholder: "Search task...",
            filter_all: "All tasks",
            filter_pending: "Pending",
            filter_submitted: "Submitted",
            filter_graded: "Graded",
            filter_overdue: "Overdue",

            stat_total: "Total Tasks",
            stat_pending: "Pending Tasks",
            stat_completed: "Completed",
            stat_avg: "Average Grade",

            status_pending: "Pending",
            status_submitted: "Submitted",
            status_graded: "Graded",
            status_overdue: "Overdue",

            deadline: "Deadline",
            grade: "Grade",
            no_grade: "None",
            open_btn: "Open",

            empty_title: "No tasks found",
            empty_text: "Try changing the search query or filter.",

            unknown_task: "Untitled task",
            course_not_specified: "Course not specified",
            no_deadline: "No deadline specified",
            exam: "Exam"
        },
        schedule: {
            page_title: "Class Schedule",
            page_desc: "Here you can view your weekly classes, time, classroom and learning format.",
            prev_week: "← Previous",
            next_week: "Next →",
            current_week: "Current Week",
            today_title: "Today",
            monday: "Monday",
            tuesday: "Tuesday",
            wednesday: "Wednesday",
            thursday: "Thursday",
            friday: "Friday",
            saturday: "Saturday",
            sunday: "Sunday",
            teacher: "Teacher",
            room: "Room",
            empty_day: "No classes",
            empty_today: "No more classes today.",
            unknown_lesson: "Untitled lesson",
            format_online: "Online",
            format_offline: "Offline",
            type_lecture: "Lecture",
            type_practical: "Practical",
            type_seminar: "Seminar",
            type_exam: "Exam",
            type_consultation: "Consultation"
        },
        grades: {
            page_title: "Grades",
            page_desc: "Here you can view your academic performance, task grades, average score and course progress.",

            stat_avg: "Average Grade",
            stat_graded: "Graded Tasks",
            stat_courses: "Courses",
            stat_best: "Best Grade",

            search_placeholder: "Search by course, task or feedback...",
            filter_all: "All courses",

            table_title: "Gradebook",
            side_title: "Course Performance",

            th_course: "Course",
            th_task: "Task",
            th_date: "Date",
            th_grade: "Grade",
            th_status: "Status",

            status_passed: "Passed",
            status_pending: "Pending",
            status_failed: "Failed",

            no_grade: "None",
            course_not_specified: "Course not specified",
            task_not_specified: "Task not specified",

            empty_title: "No grades found",
            empty_text: "Try changing the search query or filter."
        },
        profile: {
            loading: "Loading...",
            course_suffix: "year",
            btn_edit: "✏️ Edit Profile",
            btn_share: "🤝 Share",
            stat_avg: "GPA",
            stat_courses: "Active Courses",
            stat_tasks: "Tasks Completed",
            stat_attendance: "Attendance",
            stat_coins: "Coins",
            stat_achievements: "Achievements",
            tab_overview: "Overview",
            tab_grades: "Grades",
            tab_achievements: "Achievements",
            tab_activity: "Activity",
            tab_settings: "Settings",
            card_courses: "📚 Current Courses",
            card_achievements: "🏆 Latest Achievements",
            card_activity: "📊 Weekly Activity",
            card_skills: "🧠 Skills",
            card_deadlines: "⏰ Upcoming Deadlines",
            link_all: "All →",
            empty_achievements: "You have no achievements unlocked yet",
            empty_skills: "Skills will appear after completing the courses",
            submissions_count: "Submitted tasks",

            card_grades_full: "🎓 Full Academic Record",
            th_course: "Course",
            th_task: "Task",
            th_date: "Date",
            th_grade: "Grade",
            settings_security: "🛡️ Security & Access",
            label_old_password: "Current Password",
            label_new_password: "New Password",
            btn_update_password: "Update Password",
            settings_preferences: "⚙️ Interface Preferences",
            settings_lang_hint: "Language and theme can be changed in the quick access sidebar.",
            password_updated_success: "Password updated successfully!",
            tab_activity_full: "📜 Recent Activity History",
            event_grade: "Grade",
            achievements_list_tab: "🏆Achievements",
            event_achievement: "Achievement",
            empty_history: "No events recorded yet",
            link_copied: "Profile link copied"
        },
        notifications: {
            title: "Notifications",
            subtitle: "Your personal messages",
            list_title: "All notifications",
            stat_total: "Total",
            stat_unread: "Unread",
            stat_read: "Read",
            search_placeholder: "Search notifications...",
            filter_all: "All",
            filter_unread: "Unread",
            filter_read: "Read",
            empty: "No notifications yet",
            read: "Read",
            unread: "New",
            mark_read: "Mark as read",
            mark_all_read: "Mark all as read"
        },
        announcements: {
            title: "Announcements",
            subtitle: "All important course and platform messages",
            list_title: "All announcements",
            stat_total: "Total",
            stat_unread: "Unread",
            stat_read: "Read",
            search_placeholder: "Search announcements...",
            filter_all: "All",
            filter_unread: "Unread",
            filter_read: "Read",
            mark_all: "Mark all as read",
            empty: "No announcements yet",
            create_btn: "+ Create announcement",
            create_modal_title: "Create announcement",
            create_modal_desc: "Fill in the announcement data.",
            course: "Course",
            course_all: "For everyone",
            title_uk: "Title in Ukrainian",
            title_en: "Title in English",
            content_uk: "Text in Ukrainian",
            content_en: "Text in English",
            title_uk_placeholder: "For example, Platform update",
            title_en_placeholder: "For example, Platform update",
            content_uk_placeholder: "Enter announcement text in Ukrainian...",
            content_en_placeholder: "Enter announcement text in English...",
            create_submit: "Create",
            create_success: "Announcement has been created.",
            create_error: "Failed to create announcement.",
            fields_required: "Fill in all announcement fields.",
            courses_load_error: "Failed to load courses.",
            course_required_for_teacher: "Teacher must select a course.",
            no_courses_available: "No available courses."
        },
        moderator_nav: {
            dashboard: "🛡️ Panel",
            users: "👥 Users",
            courses: "📚 Courses",
            activity: "📌 Activity"
        },
        moderator_dashboard: {
            badge: "MODERATOR",
            title: "Moderator panel",
            desc: "General overview of the Mooden educational platform: users, courses, tasks, activity and system events.",

            stat_users: "Users",
            stat_courses: "Courses",
            stat_tasks: "Tasks",
            stat_submissions: "Submissions",

            stat_students: "Students",
            stat_teachers: "Teachers",
            stat_announcements: "Announcements",
            stat_attendance: "Open attendance marks",

            quick_actions: "Quick actions",

            users_title: "Users",
            users_text: "View users and change roles.",

            courses_title: "Courses",
            courses_text: "View courses, students and tasks.",

            activity_title: "Activity",
            activity_text: "Recent user actions in the system.",

            announcements_title: "Announcements",
            announcements_text: "View available platform announcements.",

            recent_activity: "Recent activity",
            recent_announcements: "Recent announcements",

            view_all: "View all",
            all: "All",

            loading: "Loading...",

            no_activity: "No activity yet.",
            no_announcements: "No new announcements yet.",

            submission_default: "Submission",
            student_default: "Student",
            course_default: "Course",

            general: "General",
            announcement_default: "Untitled announcement",
            author: "Author",

            activity_error: "Failed to load activity.",
            announcements_error: "Failed to load announcements.",
            load_error: "Failed to load moderator panel."
        },

        moderator_users: {
            badge: "MODERATOR",
            title: "Users",
            desc: "On this page, the moderator can view system users, filter them by roles, edit data, change roles, block or unblock accounts.",

            add_user: "+ Add user",

            stat_total: "Total",
            stat_students: "Students",
            stat_teachers: "Teachers",
            stat_blocked: "Blocked",

            search_placeholder: "Search by name or email...",

            all_roles: "All roles",
            students: "Students",
            teachers: "Teachers",
            moderators: "Moderators",

            all_statuses: "All statuses",
            active_users: "Active",
            blocked_users: "Blocked",

            loading_title: "Loading...",
            loading_text: "Fetching the user list.",

            empty_title: "No users found",
            empty_text: "Try changing the filter or search query.",

            no_access_title: "No access",
            no_access_text: "You need to sign in.",

            load_error_title: "Failed to load users",
            load_error_text: "Check your connection or try again later.",

            role: "Role",

            role_student: "Student",
            role_teacher: "Teacher",
            role_moderator: "Moderator",

            active: "Active",
            blocked: "Blocked",

            unknown_user: "Unknown user",
            no_email: "Email is not specified",

            edit: "Edit",
            ban: "Ban",
            unban: "Unban",

            role_updated: "User role updated.",
            role_update_error: "Failed to update the user role.",

            ban_success: "User has been blocked.",
            unban_success: "User has been unblocked.",
            ban_error: "Failed to update the user status.",

            add_modal_title: "Add user",
            add_modal_desc: "Fill in the new user data.",

            edit_modal_title: "Edit user",
            edit_modal_desc: "Update the main account data.",

            full_name: "Full name",
            full_name_placeholder: "For example, John Smith",

            lang: "Language",

            password: "Password",
            password_placeholder: "Password for the new user",

            cancel: "Cancel",
            save: "Save",

            create_success: "User created.",
            update_success: "User data updated.",
            save_error: "Failed to save user data.",
            full_name_required: "Enter the user's full name.",
            email_required: "Enter the user's email.",
            password_too_short: "Password must contain at least 6 characters.",
            email_already_exists: "A user with this email already exists."
        },

        moderator_courses: {
            badge: "MODERATOR",
            title: "Courses",
            desc: "On this page, the moderator can view platform courses, edit their main data, enroll students and assign teachers.",

            add_course: "+ Add course",

            stat_courses: "Courses",
            stat_students: "Student enrollments",
            stat_teachers: "Teacher assignments",
            stat_tasks: "Tasks",

            search_placeholder: "Search course...",
            sort_title: "By title",
            sort_students: "By students count",
            sort_teachers: "By teachers count",
            sort_tasks: "By tasks count",

            loading_title: "Loading...",
            loading_text: "Fetching the course list.",

            empty_title: "No courses found",
            empty_text: "Try changing search or sorting.",

            no_access_title: "No access",
            no_access_text: "You need to sign in.",

            load_error_title: "Failed to load courses",
            load_error_text: "Check your connection or try again later.",

            untitled: "Untitled course",
            active: "Active",
            hidden: "Hidden",
            no_description: "Course description is not specified.",

            students: "students",
            teachers: "teachers",
            tasks: "tasks",

            edit: "Edit",
            members: "Members",
            hide_course: "Hide",
            show_course: "Show",

            add_modal_title: "Add course",
            add_modal_desc: "Fill in the main information for the new course.",

            edit_modal_title: "Edit course",
            edit_modal_desc: "Update the main course information.",

            title_uk: "Ukrainian title",
            title_en: "English title",
            desc_uk: "Ukrainian description",
            desc_en: "English description",
            color: "Course color",

            cancel: "Cancel",
            save: "Save",

            members_title: "Course members",
            members_desc: "Manage students and teachers related to the course.",
            course_students: "Course students",
            course_teachers: "Course teachers",

            add_student: "Enroll",
            add_teacher: "Assign",
            remove_student: "Remove",
            remove_teacher: "Remove",

            students_empty: "No students have been enrolled yet.",
            teachers_empty: "No teachers have been assigned yet.",
            no_available_students: "No available students",
            no_available_teachers: "No available teachers",

            student_default: "Student",
            teacher_default: "Teacher",

            choose_student: "Choose a student.",
            choose_teacher: "Choose a teacher.",

            create_success: "Course created.",
            update_success: "Course updated.",
            save_error: "Failed to save course.",

            hide_success: "Course has been hidden.",
            show_success: "Course has been shown.",
            visibility_error: "Failed to update course visibility.",

            members_error: "Failed to load course members.",

            add_student_success: "Student enrolled in the course.",
            remove_student_success: "Student removed from the course.",
            add_teacher_success: "Teacher assigned to the course.",
            remove_teacher_success: "Teacher removed from the course.",

            add_student_error: "Failed to enroll student.",
            remove_student_error: "Failed to remove student.",
            add_teacher_error: "Failed to assign teacher.",
            remove_teacher_error: "Failed to remove teacher."
        },

        moderator_activity: {
            badge: "MODERATOR",
            title: "Activity",
            desc: "On this page, the moderator can view recent user actions in the system: submissions, announcements, course events and other changes.",
            refresh: "Refresh",

            stat_total: "Total events",
            stat_submissions: "Submissions",
            stat_announcements: "Announcements",
            stat_attendance: "Attendance",

            search_placeholder: "Search by student, course or title...",
            filter_all: "All types",
            filter_submissions: "Submissions",
            filter_announcements: "Announcements",
            filter_attendance: "Attendance",
            filter_notifications: "Notifications",
            filter_system: "System events",

            sort_newest: "Newest first",
            sort_oldest: "Oldest first",

            loading_title: "Loading...",
            loading_text: "Fetching system activity.",
            empty_title: "No activity found",
            empty_text: "Try changing search or filter.",
            no_access_title: "No access",
            no_access_text: "You need to sign in as moderator.",
            load_error_title: "Failed to load activity",
            load_error_text: "Check backend or moderator access rights.",

            type_submission: "Submission",
            type_announcement: "Announcement",
            type_attendance: "Attendance",
            type_notification: "Notification",
            type_default: "Activity",

            default_title: "Untitled event",
            submitted_work: "Submission",
            student: "Student",
            course: "Course",

            desc_submission: "Submitted work",
            desc_announcement: "Announcement was created or published",
            desc_attendance: "The student marked attendance for the lesson.",
            desc_notification: "System notification was created.",
            desc_default: "System event was recorded.",

            refreshed: "Activity refreshed.",
            load_error: "Failed to load activity."
        },
        moderator_profile: {
            role_badge: "Moderator profile",
            sub_info: "System moderator",
            role_tag: "🛡️ moderator",

            stat_users: "Users",
            stat_courses: "Courses",
            stat_announcements: "Announcements",
            stat_attendance: "Open attendance marks",

            info_title: "Personal information",
            full_name: "Full name",
            role: "Role",
            role_value: "Moderator",
            lang: "Interface language",

            permissions_title: "Area of responsibility",
            permission_users_title: "Users",
            permission_users_text: "View users, edit data, change roles, block and unblock accounts.",
            permission_courses_title: "Courses",
            permission_courses_text: "View courses, edit information, enroll students and assign teachers.",
            permission_activity_title: "Activity",
            permission_activity_text: "View submissions, announcements, attendance and notifications in the system.",
            permission_communication_title: "Communication",
            permission_communication_text: "View announcements and notifications related to the educational platform.",

            edit_title: "✏️ Profile editing",
            btn_update_profile: "Update profile",

            fallback_name: "Moderator",
            no_email: "Email is not specified",
            validation_error: "Fill in full name and email.",
            update_success: "Profile updated.",
            update_error: "Failed to update moderator profile.",
            unavailable_title: "Profile is unavailable",
            unavailable_text: "Failed to load moderator profile."
        },

        errors: {
            USER_BLOCKED: "Your account has been blocked.",
            INVALID_CREDENTIALS: "Invalid email or password.",
            SERVER_ERROR: "Server error. Try again later.",
            UNAUTHORIZED: "Unauthorized. Redirecting to login...",
            ACCESS_DENIED: "This page is for {role} only.",
            ROLE_ERROR: "Your role is not recognized.",
            INVALID_TOKEN: "Session expired. Please log in again.",
            USER_NOT_FOUND: "User not found",
            EMAIL_REQUIRED: "Enter your email.",
            RESET_TOKEN_REQUIRED: "Reset token is missing.",
            RESET_TOKEN_EXPIRED: "The password reset link is invalid or has expired.",
            RESET_TOKEN_VERIFY_ERROR: "Failed to verify the reset link.",
            PASSWORDS_DO_NOT_MATCH: "Passwords do not match.",
            PASSWORD_RESET_REQUEST_ERROR: "Failed to send the password reset email.",
            PASSWORD_RESET_ERROR: "Failed to update password.",
            SERVER_ERROR_DASHBOARD: "Failed to load dashboard data.",
            SERVER_ERROR_PROFILE: "Failed to load profile data",
            ERROR_MARK_READ: "Failed to mark announcement as read.",
            ERROR_UPDATE_SETTINGS: "Error updating language settings.",
            UNKNOWN_ERROR: "Something went wrong. Please try again.",
            NETWORK_ERROR: "Unable to connect to server.",
            SIDEBAR_ERROR: "Error loading sidebar menu",
            WRONG_OLD_PASSWORD: "Current password is incorrect.",
            PASSWORD_UPDATE_ERROR: "Failed to update password.",
            PASSWORD_FIELDS_REQUIRED: "Fill in the current and new password.",
            PASSWORD_TOO_SHORT: "The new password must contain at least 6 characters.",
            COPY_ERROR: "Failed to copy the link.",
            SERVER_ERROR_COURSES: "Failed to load the courses list.",
            SERVER_ERROR_TASKS: "Failed to load the tasks list.",
            SERVER_ERROR_SCHEDULE: "Failed to load class schedule.",

            TASK_NOT_FOUND: "Task not found or access denied.",
            SERVER_ERROR_TASK_DETAIL: "Failed to load task details.",
            ATTENDANCE_CLOSED: "Attendance window is closed or registration time expired.",
            ATTENDANCE_ERROR: "An error occurred while marking attendance.",
            COURSE_NOT_FOUND: "Course not found or you are not enrolled.",
            SERVER_ERROR_COURSE_DETAIL: "Failed to load course data.",
            SERVER_ERROR_ATTENDANCE: "Failed to load attendance history.",
            SUBMISSION_ALREADY_EXISTS: "The work has already been submitted.",
            SUBMISSION_ERROR: "Failed to submit work.",
            EMPTY_SUBMISSION: "Add a file or a comment to submit your work.",
            SUBMISSION_COMMENT_TOO_LONG: "Comment is too long",
            NOTIFICATIONS_ERROR: "Failed to load notifications.",
            NOTIFICATION_READ_ERROR: "Failed to update notification status.",
            ANNOUNCEMENT_FIELDS_REQUIRED: "Fill in all announcement fields.",
            ANNOUNCEMENT_CREATE_ERROR: "Failed to create announcement.",
            COURSE_REQUIRED_FOR_TEACHER: "Teacher must select a course."
        }
    }
};